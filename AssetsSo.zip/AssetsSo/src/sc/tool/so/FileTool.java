
package sc.tool.so;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;


/** 复制文件、文件夹 
 * 
 * @author scimence@163.com
 * */
public class FileTool
{
//	private static String	sdkCardLib	= "/sdcard/libs/x86";
//	
//	public static void LoadAutoStatic(String libPath)
//	{
//		CopyDir(sdkCardLib, libPath + "/x86", false);
//	}
	
	/**
	 * 输出指定目录下的文件信息
	 */
	private static void ShowDir(File dir)
	{
		if (dir.exists() && dir.isDirectory())
		{
			File[] currentFiles = dir.listFiles();
			for (File currentFile : currentFiles)
			{
				if (currentFile.isFile())
					System.out.println("File -> " + currentFile.getAbsolutePath());
				else ShowDir(currentFile);
			}
		}
	}
	
	/**
	 * 复制文件夹
	 */
	public static void CopyDir(String fromDir, String toDir, boolean replace)
	{
		File FDir = new File(fromDir);
		if (!FDir.exists() || !FDir.isDirectory()) FDir.mkdirs();
		
		File TDir = new File(toDir);
		if (!TDir.exists() || !TDir.isDirectory()) TDir.mkdirs();
		
		File[] currentFiles = FDir.listFiles();
		for (File currentFile : currentFiles)
		{
			String name = currentFile.getName();
			
			if (currentFile.isFile())
				copyFile(currentFile.getAbsolutePath(), toDir + "/" + name, replace);
			else CopyDir(fromDir + "/" + name, toDir + "/" + name, replace);
		}
	}
	
	/**
	 * 复制文件
	 */
	public static boolean copyFile(String fromFile, String toFile, boolean replace)
	{
		try
		{
			File TFile = new File(toFile);
			if (TFile.exists())
			{
				if (!replace)
					return false;
				else
				{
					TFile.delete();
					TFile = null;
				}
			}
			else
			{
				TFile.getParentFile().mkdirs();
				TFile.createNewFile();
			}
			
			FileInputStream fosfrom = new FileInputStream(fromFile);
			FileOutputStream fosto = new FileOutputStream(toFile);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int len = -1;
			while ((len = fosfrom.read(buffer)) != -1)
			{
				baos.write(buffer, 0, len);
			}
			// 从内存到写入到具体文件
			fosto.write(baos.toByteArray());
			// 关闭文件流
			baos.close();
			fosto.close();
			fosfrom.close();
			return true;
		}
		catch (Exception ex)
		{
			System.out.println(ex.toString());
			return false;
		}
	}
	
}
