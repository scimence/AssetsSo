package com.example.registermaster;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import com.AssetsSoApp.R;

public class MainActivity extends Activity {

	EditText edit1;
	EditText edit2;
	CheckBox check1;
	CheckBox check2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		edit1 = (EditText) this.findViewById(R.id.editText1);
		edit2 = (EditText) this.findViewById(R.id.editText2);
		check1 = (CheckBox) this.findViewById(R.id.checkBox1);
		check2 = (CheckBox) this.findViewById(R.id.checkBox2);
	}
	
	public void GetSerial(View v) {
		String machineSerial = edit1.getText().toString();
		String Serial = Register.RegSerial(machineSerial, check1.isChecked());
		if(check2.isChecked()) Serial = Serial.replace("-", "").toLowerCase();
		edit2.setText(Serial);
	}


}
